<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // A duplicate that slips in before the index exists would make the
        // ALTER fail on production data, so surface the exact invoices first.
        $duplicates = DB::table('fee_invoices')
            ->selectRaw("CONCAT(school_id, ':', student_id, ':', academic_session_id, ':', billing_period) AS active_key, COUNT(*) AS invoices")
            ->where('status', '!=', 'cancelled')
            ->whereNotNull('billing_period')
            ->groupBy('active_key')
            ->havingRaw('COUNT(*) > 1')
            ->orderByDesc('invoices')
            ->limit(10)
            ->get();

        if ($duplicates->isNotEmpty()) {
            throw new RuntimeException(
                'Cancel the duplicate active invoices before running this migration: '
                .$duplicates->map(fn (object $row): string => $row->active_key.' ('.$row->invoices.' invoices)')->implode(', ')
            );
        }

        // IF NOT EXISTS keeps the statement safe to re-run through phpMyAdmin,
        // where an aborted import leaves earlier statements applied.
        DB::statement(<<<'SQL'
ALTER TABLE `fee_invoices`
    ADD COLUMN IF NOT EXISTS `active_billing_key` VARCHAR(96) CHARACTER SET ascii
        GENERATED ALWAYS AS (
            CASE
                WHEN `status` <> 'cancelled' AND `billing_period` IS NOT NULL
                THEN CONCAT(`school_id`, ':', `student_id`, ':', `academic_session_id`, ':', `billing_period`)
            END
        ) STORED
SQL);

        DB::statement('ALTER TABLE `fee_invoices` ADD UNIQUE KEY IF NOT EXISTS `fee_invoices_active_billing_unique` (`active_billing_key`)');
    }

    public function down(): void
    {
        DB::statement('ALTER TABLE `fee_invoices` DROP INDEX IF EXISTS `fee_invoices_active_billing_unique`');
        DB::statement('ALTER TABLE `fee_invoices` DROP COLUMN IF EXISTS `active_billing_key`');
    }
};
