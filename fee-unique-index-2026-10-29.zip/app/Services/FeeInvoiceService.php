<?php

namespace App\Services;

use App\Models\Enrollment;
use App\Models\FeeDiscount;
use App\Models\FeeInvoice;
use App\Models\FeeInvoiceDiscount;
use App\Models\FeeStructure;
use App\Models\School;
use App\Models\User;
use App\Support\AuditLogger;
use App\Support\NumberSequence;
use App\Support\SchoolContext;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class FeeInvoiceService
{
    public function __construct(
        private readonly AuditLogger $audit,
        private readonly NumberSequence $numbers,
    ) {}

    /**
     * @param  array<string, mixed>  $data
     * @return array{invoices: list<FeeInvoice>, skipped: int, total: float}
     */
    public function generate(User $actor, array $data): array
    {
        $schoolId = $this->schoolId();
        $sessionId = (int) $data['academic_session_id'];
        $classId = (int) $data['class_id'];
        $sectionId = filled($data['section_id'] ?? null) ? (int) $data['section_id'] : null;
        $typeIds = array_values(array_unique(array_map('intval', (array) $data['fee_type_ids'])));
        $billingPeriod = filled($data['billing_period'] ?? null) ? (string) $data['billing_period'] : null;
        $issueDate = Carbon::parse((string) $data['issue_date']);
        $dueDate = Carbon::parse((string) $data['due_date']);

        if ($typeIds === []) {
            throw ValidationException::withMessages([
                'fee_type_ids' => __('Choose at least one fee type.'),
            ]);
        }

        $structures = FeeStructure::query()
            ->where('academic_session_id', $sessionId)
            ->where('class_id', $classId)
            ->whereIn('fee_type_id', $typeIds)
            ->where('is_active', true)
            ->with(['feeType', 'schoolClass'])
            ->orderBy('id')
            ->get();

        if ($structures->count() !== count($typeIds)) {
            throw ValidationException::withMessages([
                'fee_type_ids' => __('Some selected fee types do not have an active structure for this class and session.'),
            ]);
        }

        $enrollments = Enrollment::query()
            ->with(['student', 'section'])
            ->where('academic_session_id', $sessionId)
            ->where('class_id', $classId)
            ->when($sectionId !== null, fn ($query) => $query->where('section_id', $sectionId))
            ->where('status', 'active')
            ->orderBy('roll_no')
            ->get()
            ->filter(fn (Enrollment $enrollment): bool => $enrollment->student !== null);

        if ($enrollments->isEmpty()) {
            throw ValidationException::withMessages([
                'class_id' => __('There are no active students enrolled in this class for the selected session.'),
            ]);
        }

        $studentIds = $enrollments->pluck('student_id')->unique()->values();

        $alreadyInvoiced = FeeInvoice::query()
            ->whereIn('student_id', $studentIds)
            ->where('academic_session_id', $sessionId)
            ->where('status', '!=', 'cancelled')
            ->when(
                $billingPeriod !== null,
                fn ($query) => $query->where('billing_period', $billingPeriod),
                fn ($query) => $query->whereHas('items', fn ($query) => $query->whereIn('fee_type_id', $typeIds)),
            )
            ->pluck('student_id')
            ->all();

        $eligible = $enrollments
            ->reject(fn (Enrollment $enrollment): bool => in_array($enrollment->student_id, $alreadyInvoiced, true))
            ->values();

        if ($eligible->isEmpty()) {
            throw ValidationException::withMessages([
                'class_id' => __('Every active student in this class already has an invoice for the selected fee types and period.'),
            ]);
        }

        return DB::transaction(function () use ($actor, $schoolId, $sessionId, $classId, $billingPeriod, $issueDate, $dueDate, $structures, $enrollments, $eligible): array {
            School::query()->whereKey($schoolId)->lockForUpdate()->firstOrFail();

            if ($billingPeriod !== null) {
                // The eligibility check above ran before this transaction, so a
                // concurrent generate may have billed the same period while we
                // waited for the school lock. Re-read under the lock.
                $invoicedNow = FeeInvoice::query()
                    ->whereIn('student_id', $eligible->pluck('student_id'))
                    ->where('academic_session_id', $sessionId)
                    ->where('status', '!=', 'cancelled')
                    ->where('billing_period', $billingPeriod)
                    ->lockForUpdate()
                    ->pluck('student_id')
                    ->all();

                $eligible = $eligible
                    ->reject(fn (Enrollment $enrollment): bool => in_array($enrollment->student_id, $invoicedNow, true))
                    ->values();
            }

            if ($eligible->isEmpty()) {
                throw ValidationException::withMessages([
                    'class_id' => __('Every active student in this class already has an invoice for the selected fee types and period.'),
                ]);
            }

            $invoices = [];
            $total = 0.0;

            foreach ($eligible as $enrollment) {
                try {
                    $invoice = FeeInvoice::query()->create([
                        'academic_session_id' => $sessionId,
                        'student_id' => $enrollment->student_id,
                        'enrollment_id' => $enrollment->id,
                        'invoice_no' => $this->numbers->next(FeeInvoice::class, 'invoice_no', 'INV', (int) $issueDate->year, $schoolId),
                        'billing_period' => $billingPeriod,
                        'issue_date' => $issueDate->toDateString(),
                        'due_date' => $dueDate->toDateString(),
                        'subtotal' => 0,
                        'discount_total' => 0,
                        'total' => 0,
                        'paid_total' => 0,
                        'due_total' => 0,
                        'status' => 'issued',
                        'notes' => $data['notes'] ?? null,
                        'created_by' => $actor->id,
                    ]);
                } catch (UniqueConstraintViolationException) {
                    // The unique billing key caught a race that started before
                    // this transaction held the school lock.
                    continue;
                }

                $subtotal = 0.0;

                foreach ($structures as $structure) {
                    $amount = round((float) $structure->amount, 2);

                    $invoice->items()->create([
                        'fee_type_id' => $structure->fee_type_id,
                        'description' => $structure->name ?: ($structure->feeType?->name ?? __('Fee')),
                        'quantity' => 1,
                        'unit_amount' => $amount,
                        'discount_amount' => 0,
                        'line_total' => $amount,
                    ]);

                    $subtotal += $amount;
                }

                $subtotal = round($subtotal, 2);

                $invoice->update([
                    'subtotal' => $subtotal,
                    'total' => $subtotal,
                    'due_total' => $subtotal,
                ]);

                $invoices[] = $invoice;
                $total += $subtotal;
            }

            $this->audit->log(
                event: 'fee_invoices.generated',
                auditable: null,
                description: __(':count fee invoices were generated for :class', [
                    'count' => count($invoices),
                    'class' => $structures->first()?->schoolClass?->name ?? (string) $classId,
                ]),
                newValues: [
                    'academic_session_id' => $sessionId,
                    'class_id' => $classId,
                    'billing_period' => $billingPeriod,
                    'invoice_nos' => array_slice(array_map(fn (FeeInvoice $invoice): string => $invoice->invoice_no, $invoices), 0, 25),
                    'count' => count($invoices),
                    'total' => round($total, 2),
                ],
                actor: $actor,
                schoolId: $schoolId,
            );

            return [
                'invoices' => $invoices,
                'skipped' => $enrollments->count() - count($invoices),
                'total' => round($total, 2),
            ];
        });
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function applyDiscount(User $actor, FeeInvoice $invoice, array $data): FeeInvoice
    {
        return DB::transaction(function () use ($actor, $invoice, $data): FeeInvoice {
            /** @var FeeInvoice $locked */
            $locked = FeeInvoice::query()->lockForUpdate()->findOrFail($invoice->getKey());

            $this->guardEditable($locked);

            /** @var FeeDiscount $discount */
            $discount = FeeDiscount::query()->findOrFail((int) $data['fee_discount_id']);

            if (! $discount->is_active) {
                throw ValidationException::withMessages([
                    'fee_discount_id' => __('This discount is no longer active.'),
                ]);
            }

            $base = $discount->applies_to_fee_type_id !== null
                ? round((float) $locked->items()->where('fee_type_id', $discount->applies_to_fee_type_id)->sum('line_total'), 2)
                : round((float) $locked->subtotal, 2);

            if ($base <= 0) {
                throw ValidationException::withMessages([
                    'fee_discount_id' => __('This discount does not apply to any item on the invoice.'),
                ]);
            }

            $amount = $discount->type === 'percent'
                ? round($base * ((float) $discount->value / 100), 2)
                : round((float) $discount->value, 2);

            $remaining = round((float) $locked->subtotal - (float) $locked->discounts()->sum('amount'), 2);
            $amount = min($amount, $remaining);

            if ($amount <= 0) {
                throw ValidationException::withMessages([
                    'fee_discount_id' => __('There is no remaining balance to discount on this invoice.'),
                ]);
            }

            $locked->discounts()->create([
                'fee_discount_id' => $discount->id,
                'name' => $discount->name,
                'type' => $discount->type,
                'value' => $discount->value,
                'amount' => $amount,
            ]);

            $this->recalculateDiscounts($locked);

            $this->audit->log(
                event: 'fee_invoice.discount_applied',
                auditable: $locked,
                description: __('Discount :name was applied to invoice :invoice', ['name' => $discount->name, 'invoice' => $locked->invoice_no]),
                newValues: [
                    'fee_discount_id' => $discount->id,
                    'amount' => $amount,
                    'total' => (float) $locked->refresh()->total,
                ],
                actor: $actor,
                schoolId: (int) $locked->school_id,
            );

            return $locked->refresh();
        });
    }

    public function removeDiscount(User $actor, FeeInvoice $invoice, FeeInvoiceDiscount $discount): FeeInvoice
    {
        return DB::transaction(function () use ($actor, $invoice, $discount): FeeInvoice {
            /** @var FeeInvoice $locked */
            $locked = FeeInvoice::query()->lockForUpdate()->findOrFail($invoice->getKey());

            $this->guardEditable($locked);

            if ((int) $discount->fee_invoice_id !== (int) $locked->id) {
                abort(404, __('Discount not found on this invoice.'));
            }

            $discount->delete();

            $this->recalculateDiscounts($locked);

            $this->audit->log(
                event: 'fee_invoice.discount_removed',
                auditable: $locked,
                description: __('Discount :name was removed from invoice :invoice', ['name' => $discount->name, 'invoice' => $locked->invoice_no]),
                oldValues: ['name' => $discount->name, 'amount' => (float) $discount->amount],
                newValues: ['total' => (float) $locked->refresh()->total],
                actor: $actor,
                schoolId: (int) $locked->school_id,
            );

            return $locked->refresh();
        });
    }

    public function cancel(User $actor, FeeInvoice $invoice): FeeInvoice
    {
        return DB::transaction(function () use ($actor, $invoice): FeeInvoice {
            /** @var FeeInvoice $locked */
            $locked = FeeInvoice::query()->lockForUpdate()->findOrFail($invoice->getKey());

            if ((float) $locked->paid_total > 0) {
                throw ValidationException::withMessages([
                    'invoice' => __('Invoices with recorded payments cannot be cancelled. Reverse the payments first.'),
                ]);
            }

            if ($locked->status === 'cancelled') {
                return $locked;
            }

            $locked->update(['status' => 'cancelled']);

            $this->audit->log(
                event: 'fee_invoice.cancelled',
                auditable: $locked,
                description: __('Invoice :invoice was cancelled', ['invoice' => $locked->invoice_no]),
                oldValues: ['status' => 'issued', 'total' => (float) $locked->total],
                newValues: ['status' => 'cancelled'],
                actor: $actor,
                schoolId: (int) $locked->school_id,
            );

            return $locked->refresh();
        });
    }

    private function recalculateDiscounts(FeeInvoice $invoice): void
    {
        $discountTotal = round((float) $invoice->discounts()->sum('amount'), 2);
        $paid = round((float) $invoice->paid_total, 2);
        $total = max(0, round((float) $invoice->subtotal - $discountTotal, 2));
        $due = max(0, round($total - $paid, 2));

        $status = match (true) {
            $due <= 0 => 'paid',
            $paid > 0 => 'partial',
            default => 'issued',
        };

        $invoice->update([
            'discount_total' => $discountTotal,
            'total' => $total,
            'due_total' => $due,
            'status' => $status,
        ]);

        $invoice->refresh();
    }

    private function guardEditable(FeeInvoice $invoice): void
    {
        if ($invoice->status === 'cancelled') {
            throw ValidationException::withMessages([
                'invoice' => __('Cancelled invoices cannot be changed.'),
            ]);
        }

        if ((float) $invoice->paid_total > 0) {
            throw ValidationException::withMessages([
                'invoice' => __('Payments already exist on this invoice. Reverse them before changing discounts.'),
            ]);
        }
    }

    private function schoolId(): int
    {
        $schoolId = app(SchoolContext::class)->id();

        if ($schoolId === null) {
            throw ValidationException::withMessages([
                'school' => __('A school context is required.'),
            ]);
        }

        return $schoolId;
    }
}
